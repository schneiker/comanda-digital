package com.ibeus.Comanda.Digital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComandaDigitalApplicationTests {

	@Test
	void contextLoads() {
	}

}
