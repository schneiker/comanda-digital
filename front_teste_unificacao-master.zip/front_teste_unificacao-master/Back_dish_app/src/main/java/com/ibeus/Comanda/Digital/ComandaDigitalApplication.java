package com.ibeus.Comanda.Digital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComandaDigitalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComandaDigitalApplication.class, args);
	}
}	