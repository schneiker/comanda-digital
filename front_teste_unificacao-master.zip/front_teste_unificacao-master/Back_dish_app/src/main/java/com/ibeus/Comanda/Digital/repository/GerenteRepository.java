package com.ibeus.Comanda.Digital.repository;

import com.ibeus.Comanda.Digital.model.Gerente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GerenteRepository extends JpaRepository<Gerente, Long> {
}
