package com.ibeus.Comanda.Digital.repository;

import com.ibeus.Comanda.Digital.model.Motoboy;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MotoboyRepository extends JpaRepository<Motoboy, Long> {
}
