import { Component, Input  } from '@angular/core';

@Component({
  selector: 'app-entregador-info-cliente-e-pedido',
  standalone: true,
  imports: [],
  templateUrl: './entregador-info-cliente-e-pedido.component.html',
  styleUrl: './entregador-info-cliente-e-pedido.component.css'
})
export class EntregadorInfoClienteEPedidoComponent {
  @Input()
  nomeCliente!: string;
  @Input()
  numeroPedido!: number;
}
