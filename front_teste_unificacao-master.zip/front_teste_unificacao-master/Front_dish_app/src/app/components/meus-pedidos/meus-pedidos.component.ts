import { Component } from '@angular/core';

@Component({
  selector: 'app-meus-pedidos',
  standalone: true,
  imports: [],
  templateUrl: './meus-pedidos.component.html',
  styleUrl: './meus-pedidos.component.css'
})
export class MeusPedidosComponent {

}
