// src/environments/environment.prod.ts
export const environment = {
    production: true,
    apiUrl: 'https://api.example.com'  // URL para o ambiente de produção
  };